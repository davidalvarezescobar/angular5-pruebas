import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';

import { ComponentsModule } from './../components/components.module';


export const routes: Routes = [
  { path: '', loadChildren: './home/home.module#HomeModule' },
  { path: '**', loadChildren: './page-not-found/page-not-found.module#PageNotFoundModule' }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes),
    ComponentsModule
  ],
  providers: [],
  exports: [RouterModule]
})
export class PagesModule { }
