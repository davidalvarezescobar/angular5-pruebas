import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

// Internal modules
import { PagesModule } from './pages/pages.module';
import { ComponentsModule } from './components/components.module';
import { CoreModule } from './services/core.module';

// Bootstrap
import { AppComponent } from './app.component';


@NgModule({
  imports: [
    BrowserModule,
    PagesModule,
    CoreModule,
    ComponentsModule
  ],
  declarations: [
    AppComponent
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
