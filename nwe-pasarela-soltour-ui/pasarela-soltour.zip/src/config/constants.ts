export const CONFIG = {
  production: true
}
